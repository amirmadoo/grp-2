import sys      
from PyQt5.QtWidgets import QApplication, QWidget, QLabel

class HyperlinkLabel(QLabel):
    
    def _init_(self, parent=None):
        super()._init_()
        self.setStyleSheet('font-size: 50px')
        self.setOpenExternalLinks(True)
        self.setParent(parent)

class AppDemo(QWidget):
    def _init_(self):
        super()._init_()

        linkTemplate = '<a href={0}>{1}</a>'

        label1 = HyperlinkLabel(self)
        label1.setText(linkTemplate.format( 'https://drive.google.com/drive/folders/1E7Pt2ePQ7NSrvD3V1IDulfPDTSR0jQvs?usp=sharing', 'OOPS Concept'))
        label1.move(100,250)

        label2 = HyperlinkLabel(self)
        label2.setText(linkTemplate.format('https://drive.google.com/drive/folders/1SzAgFxdFppsSKQMUkjiDrVdi-7o4jiAZ?usp=sharing', 'Exception Handling'))
        label2.move(100, 100)

        label3 = HyperlinkLabel(self)
        label3.setText(linkTemplate.format('https://drive.google.com/drive/folders/1jxOXBq5m5yHz-R_cVWbiBbRg58hzmIiS?usp=sharing','Working with database'))
        label3.move(100,500)
   
if __name__== '_main_':
    app = QApplication(sys.argv)
    demo = AppDemo()
    demo.show()
    sys.exit(app.exec_())
    

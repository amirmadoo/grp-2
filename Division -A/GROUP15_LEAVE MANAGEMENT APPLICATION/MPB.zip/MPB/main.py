import tkinter, sqlite3, random
import tkinter.messagebox as tk
from calendar import Calendar
from tkinter.font import Font
from tkinter import *
# from turtle import *
from easygui import *
from tkcalendar import *
from datetime import datetime, timedelta

# from createdb import *

conn = sqlite3.connect('leaveDb.db')
cur = conn.cursor()


#####################################################################################################
# FACULTY STUFF
def StudentAllInformationWindow():
    allStudentInformation = Toplevel()
    r = conn.execute('SELECT Student_id,Name,ContactNumber FROM Student').fetchall()
    p = ('STUDENT ID', 'NAME', 'CONTACT')
    r.insert(0,p)
    total_rows = len(r)
    total_columns = len(r[0])
    for i in range(total_rows):
        for j in range(total_columns):
            e = Entry(allStudentInformation, width=15, fg='blue',
                      font=('Arial', 16, 'bold'))
            e.grid(row=i, column=j)
            e.insert(END, r[i][j])



def LeaveApproval():
    message = "Enter leave_id : "
    title = "Leave Approval"
    fieldNames = ["Leave_id"]
    fieldValues = []
    fieldValues = multenterbox(message, title, fieldNames)
    message1 = "Approve / Deny"
    title1 = "Leave Approval"
    choices = ["APPROVE", "DENY"]
    choice = choicebox(message1, title1, choices)

    conn.execute("UPDATE status SET status = ? WHERE leave_id= ?", (choice, fieldValues[0]))
    conn.commit()

    if choice == 'approve':
        print(0)
        cur.execute("SELECT leave FROM status WHERE leave_id=?", (fieldValues[0],))
        row = cur.fetchall()
        col = row

        for row in conn.execute("SELECT Student_id FROM status WHERE leave_id=?", (fieldValues[0],)):
            print(2)
            exampleId = row[0]

        for row in conn.execute("SELECT days FROM status WHERE leave_id=?", (fieldValues[0],)):
            print(2)
            exampleDays = row[0]

        for row in conn.execute("SELECT sickleave from balance where Student_id=?", (exampleId,)):
            balance = row[0]
            print(balance)

        for row in conn.execute("SELECT casualleave from balance where Student_id=?", (exampleId,)):
            balance1 = row[0]
            print(balance1)

        for row in conn.execute("SELECT emergencyleave from balance where Student_id=?", (exampleId,)):
            balance2 = row[0]
            print(balance2)

        if (col[0] == ('sickleave',)):
            print(3)
            conn.execute("UPDATE balance SET sickleave =? WHERE Student_id= ?", ((balance - exampleDays), (exampleId)))

        if (col[0] == ('casualleave',)):
            print(3)
            conn.execute("UPDATE balance SET casualleave =? WHERE Student_id= ?",
                         ((balance1 - exampleDays), (exampleId)))

        if (col[0] == ('emergencyleave',)):
            print(3)
            conn.execute("UPDATE balance SET emergencyleave =? WHERE Student_id= ?",
                         ((balance2 - exampleDays), (exampleId)))


def leavelist():
    leavelistwindow = Toplevel()
    r = conn.execute('SELECT * from status').fetchall()
    p = ('LEAVE ID','STUDENT ID','LEAVE TYPE','FROM','TO','TOTAL DAYS','STATUS')
    r.insert(0, p)
    total_rows = len(r)
    total_columns = len(r[0])
    for i in range(total_rows):
        for j in range(total_columns):
            e = Entry(leavelistwindow, width=15, fg='blue',
                      font=('Arial', 16, 'bold'))
            e.grid(row=i, column=j)
            e.insert(END, r[i][j])


def Facultywindow():
    Facultymainwindow = Toplevel()
    Facultymainwindow.wm_attributes('-fullscreen', '1')
    Background_Label = Label(Facultymainwindow, image=filename)
    # BG

    background_label = Label(Facultymainwindow, image=filename1)
    background_label.place(x=0, y=0, relheight=1, relwidth=1)
    # x = 0, y = 0, relwidth = 10, relheight = 10
    informationStudent = Button(Facultymainwindow, text='All Student information', command=StudentAllInformationWindow,
                                bd=12, relief=RAISED, fg="black", bg="#20B2AA",
                                font=("Times New Roman", 36, "bold"), pady=3, height=1, width=18)
    informationStudent['font'] = BtnFont
    informationStudent.place(x=900, y=200)

    LeaveListButton = Button(Facultymainwindow, text='Leave approval list', command=leavelist, bd=12, relief=RAISED,
                             fg="black", bg="#20B2AA",
                             font=("Times New Roman", 36, "bold"), pady=3, height=1, width=18)
    LeaveListButton['font'] = BtnFont
    LeaveListButton.place(x=900, y=300)

    ApprovalButton = Button(Facultymainwindow, text='Approve leave', command=LeaveApproval, bd=12, relief=RAISED,
                            fg="black", bg="#20B2AA",
                            font=("Times New Roman", 36, "bold"), pady=3, height=1, width=18)
    ApprovalButton['font'] = BtnFont
    ApprovalButton.place(x=900, y=400)

    LogoutBtn = Button(Facultymainwindow, text='Logout', command=Facultymainwindow.destroy, bd=12, relief=RAISED,
                       fg="black", bg="#20B2AA", font=("Times New Roman", 36, "bold"), pady=3, height=1, width=18)
    LogoutBtn['font'] = BtnFont
    LogoutBtn.place(x=900, y=500)


def FacultyLogin():
    message = "Enter Username and Password: "
    title = "Faculty Login"
    fieldnames = ["Username", "Password"]
    field = []
    field = multpasswordbox(message, title, fieldnames)
    if field[0] == 'admin' and field[1] == 'admin':
        tkinter.messagebox.showinfo("Faculty Login", "Login Successful.")
        Facultywindow()
    else:
        tk.showerror("Wrong info entered. ", "Incorrect username or password")


#####################################################################################################

#####################################################################################################
# STUDENT STUFF

def already_registered(stud_id):
    r = conn.execute(f'SELECT * FROM Student where Student_id = {stud_id}').fetchall()
    if (len(r) == 0):
        return "no"
    else:
        return "yes"


def check_contact(number):
    if len(str(number)) != 10:
        return "The number should be 10 digits"
    else:
        return "all_good"


def registration():
    message = "Enter Details of Student"
    title = "Registration"
    fieldNames = ["Student ID", "Name", "Contact Number", "Password"]
    fieldValues = []
    fieldValues = multpasswordbox(message, title, fieldNames)
    while 1:
        if fieldValues == None:
            break
        errmsg = ""

        if fieldValues[0].isdigit() == False:
            errmsg = errmsg + "Student ID can only be an integer\n"
        if fieldValues[2].isdigit() == False:
            errmsg = errmsg + "Contact Number can only contain digits\n"
        if not (len(str(fieldValues[0])) == 8):
            errmsg = errmsg + "Student ID can only be of 8 digits \n"
        if not str(fieldValues[1]).isalpha() == True:
            errmsg = errmsg + "Name can only contain Alphabets \n"
        if not (check_contact(fieldValues[2]) == "all_good"):
            errmsg = errmsg + (check_contact(fieldValues[2]))
        for i in range(len(fieldNames)):
            if fieldValues[i].strip() == "":
                errmsg = errmsg + ('"%s" is a required field.\n\n' % fieldNames[i])
        if errmsg == "":
            if already_registered(fieldValues[0]) == "yes":
                errmsg = errmsg + "Student ID is already registered \n"
        if errmsg == "": break

        fieldValues = multpasswordbox(errmsg, title, fieldNames, fieldValues)
    conn.execute("INSERT INTO Student(Student_id,Name,ContactNumber,Password) VALUES (?,?,?,?)",
                 (fieldValues[0], fieldValues[1], fieldValues[2], fieldValues[3]))
    conn.execute("INSERT INTO balance(Student_id,sickleave,casualleave,emergencyleave) VALUES (?,?,?,?)",
                 (fieldValues[0], 10, 15, 10))
    conn.commit()
    tkinter.messagebox.showinfo("Student Registration", "Successful Registration")


def balance():
    global login
    # check = (login,)
    global balanced_new
    balanced_new = []
    # for i in conn.execute('SELECT * FROM balance WHERE Student_id = ?', check):
    #    balanced = i
    std_id_val = login
    sick_leave_count = 0
    emergency_leave_count = 0
    max_sl = 35
    max_el = 50
    db_data = conn.execute(f'SELECT * FROM status where Student_id = {std_id_val}').fetchall()
    for data in db_data:
        l = data[2]
        if data[6] == "APPROVE":
            if l == "Sick leave":
                sick_leave_count += data[5]
            else:
                emergency_leave_count += data[5]
    sl_balance = max_sl - sick_leave_count
    el_balance = max_el - emergency_leave_count
    # print("*"*30)
    # print(sl_taken)
    # print(el_taken)
    balanced_new.append(std_id_val)
    balanced_new.append(sl_balance)
    balanced_new.append(el_balance)
    WindowBalance()


def WindowBalance():
    global balanced_new
    balanceWindow = Toplevel(root)
    label_1 = Label(balanceWindow, text="Student ID: ", fg="black", justify=LEFT, font=("Times New Roman", 16))
    label_2 = Label(balanceWindow, text=balanced_new[0], font=("Times New Roman", 16))
    label_3 = Label(balanceWindow, text="Sick Leave: ", fg="black", font=("Times New Roman", 16), justify=LEFT)
    label_4 = Label(balanceWindow, text=balanced_new[1], font=("Times New Roman", 16))
    # label_5 = Label(balanceWindow, text="Casual Leave: ", fg="black", font=("Times New Roman", 16), justify=LEFT)
    # label_6 = Label(balanceWindow, text=balanced[2], font=("Times New Roman", 16))
    label_7 = Label(balanceWindow, text="Emergency Leave: ", fg="black", font=("Times New Roman", 16), justify=LEFT)
    label_8 = Label(balanceWindow, text=balanced_new[2], font=("Times New Roman", 16))
    label_1.grid(row=0, column=0)
    label_2.grid(row=0, column=1)
    label_3.grid(row=1, column=0)
    label_4.grid(row=1, column=1)
    # label_5.grid(row=2, column=0)
    # label_6.grid(row=2, column=1)
    label_7.grid(row=2, column=0)
    label_8.grid(row=2, column=1)


def apply_submit():
    global login
    global ApplyWindow
    global std_id_field, from_date_field, to_date_field, no_of_days_field, type_of_leave_field, variable
    std_id_val = login
    from_date_val = from_date_field.get_date()
    to_date_val = to_date_field.get_date()
    type_of_leave_val = variable.get()
    leaveid = random.randint(10000, 500000)
    start_date = datetime.strptime(from_date_field.get_date(), "%d/%m/%Y")
    end_date = datetime.strptime(to_date_field.get_date(), "%d/%m/%Y")
    diff = (end_date - start_date).days + 1
    db_data = conn.execute(f'SELECT * FROM status where Student_id = {std_id_val}').fetchall()
    total_days = 0
    sl_count = 0
    el_count = 0
    for data in db_data:
        if data[
            6] == "APPROVE":  ## uncomment this line and indent the below one to make sure only approve leaves are totalled
            total_days += data[5]
            if data[2] == "Sick leave":
                sl_count += 1
            else:
                el_count += 1
    if type_of_leave_val == "Sick leave":
        if sl_count >= 30:
            tkinter.messagebox.showinfo("Apply Status", "Sorry could not apply for leave. You are eligible for " + str(
                0) + " sick leave")
        elif (sl_count + diff) > 30:
            sl = sl_count + diff - 30
            sl = diff - sl
            ApplyWindow.destroy()
            tkinter.messagebox.showinfo("Apply Status", "Sorry could not apply for leave. You are eligible for " + str(
                sl) + " days sick leave")
        else:
            conn.execute("INSERT INTO status(leave_id,Student_id,leave,Date1,Date2,days,status) VALUES (?,?,?,?,?,?,?)",
                         (leaveid, std_id_val, type_of_leave_val, start_date, end_date, diff, "Pending"))
            conn.commit()
            ApplyWindow.destroy()
            tkinter.messagebox.showinfo("Apply Status",
                                        type_of_leave_val + " applied successfully for " + str(diff) + " days")
    elif type_of_leave_val == "Emergency leave":
        if el_count >= 50:
            tkinter.messagebox.showinfo("Apply Status", "Sorry could not apply for leave. You are eligible for " + str(
                0) + " emergency leave")
        elif (el_count + diff) > 50:
            el = el_count + diff - 50
            el = diff - el
            ApplyWindow.destroy()
            tkinter.messagebox.showinfo("Apply Status", "Sorry could not apply for leave. You are eligible for " + str(
                el) + " days emergency leave")
        else:
            conn.execute("INSERT INTO status(leave_id,Student_id,leave,Date1,Date2,days,status) VALUES (?,?,?,?,?,?,?)",
                         (leaveid, std_id_val, type_of_leave_val, start_date, end_date, diff, "Pending"))
            conn.commit()
            ApplyWindow.destroy()
            tkinter.messagebox.showinfo("Apply Status",
                                        type_of_leave_val + " applied successfully for " + str(diff) + " days")


def date_range(start, stop):
    # global dates  # If you want to use this outside of functions
    dates = []
    diff = (stop - start).days
    for i in range(diff + 1):
        day = start + timedelta(days=i)
        dates.append(day)
    if dates:
        apply_submit()
        # print(dates)  # Print it, or even make it global to access it outside this
    else:
        tk.showerror("Wrong dates selected", 'Make sure the end date is later than start date')


def apply():
    global login
    global ApplyWindow
    global std_id_field, from_date_field, to_date_field, no_of_days_field, type_of_leave_field, variable
    ApplyWindow = Toplevel()
    std_id = Label(ApplyWindow, text="Student ID").grid(row=0, column=0)
    from_date = Label(ApplyWindow, text="From Date: ").grid(row=1, column=0)
    to_date = Label(ApplyWindow, text="To Date: ").grid(row=2, column=0)
    no_of_days = Label(ApplyWindow, text="No : of days").grid(row=3, column=0)
    type_of_leave = Label(ApplyWindow, text="Select type of leave").grid(row=4, column=0)
    std_id_field = Label(ApplyWindow, text=login)
    std_id_field.grid(row=0, column=1)
    from_date_field = Calendar(ApplyWindow, selectmode="day", date_pattern="dd/mm/y", year=2021, month=3, day=3)
    from_date_field.grid(row=1, column=1)
    to_date_field = Calendar(ApplyWindow, selectmode="day", date_pattern="dd/mm/y", year=2021, month=3, day=4)
    to_date_field.grid(row=2, column=1)
    # no_of_days_field = Label(ApplyWindow,text = "100").grid(row = 3,column = 1)
    choices = ["Sick leave", "Emergency leave"]
    variable = StringVar(ApplyWindow)
    variable.set("Sick leave")
    type_of_leave_field = OptionMenu(ApplyWindow, variable, *choices)
    type_of_leave_field.grid(row=4, column=1)
    ApplyBtn = Button(ApplyWindow, text='Apply',
                      command=lambda: date_range(datetime.strptime(from_date_field.get_date(), "%d/%m/%Y"), \
                                                 datetime.strptime(to_date_field.get_date(), "%d/%m/%Y"))).grid(row=5,
                                                                                                                column=0)


def Studentlogout():
    global login
    login = -1
    LoginWindow.destroy()


def StudentLeaveStatus():
    leaveStatus = Toplevel()
    global login
    r = conn.execute(f'SELECT * FROM status where Student_id={login} ORDER BY leave_id  DESC LIMIT 1').fetchall()
    p = ('LEAVE ID', 'STUDENT ID', 'LEAVE TYPE', 'FROM', 'TO', 'TOTAL DAYS', 'STATUS')
    r.insert(0, p)
    total_rows = len(r)
    total_columns = len(r[0])
    for i in range(total_rows):
        for j in range(total_columns):
            e = Entry(leaveStatus, width=15, fg='blue',
                      font=('Arial', 16, 'bold'))

            e.grid(row=i, column=j)
            e.insert(END, str(r[i][j]))


def StudentAllStatus():
    allStatus = Toplevel()
    global login
    r = conn.execute(f'SELECT * FROM status where Student_id={login}').fetchall()
    p = ('LEAVE ID', 'STUDENT ID', 'LEAVE TYPE', 'FROM', 'TO', 'TOTAL DAYS', 'STATUS')
    r.insert(0, p)
    total_rows = len(r)
    total_columns = len(r[0])
    for i in range(total_rows):
        for j in range(total_columns):
            e = Entry(allStatus, width=15, fg='blue',
                      font=('Arial', 16, 'bold'))

            e.grid(row=i, column=j)
            e.insert(END, str(r[i][j]))


def StudentInformationWindow():
    StudentInformation = Toplevel()
    txt = Text(StudentInformation)
    r = conn.execute('SELECT Student_id,Name,ContactNumber FROM Student').fetchall()
    p = ('STUDENT ID', 'NAME', 'CONTACT')
    r.insert(0, p)
    total_rows = len(r)
    total_columns = len(r[0])
    for i in range(total_rows):
        for j in range(total_columns):
            e = Entry(StudentInformation, width=20, fg='blue',
                      font=('Arial', 16, 'bold'))
            e.grid(row=i, column=j)
            e.insert(END, r[i][j])


def StudentLoginWindow():
    # Student login window after successful login
    global LoginWindow
    global login
    LoginWindow = Toplevel()
    LoginWindow.wm_attributes('-fullscreen', '1')
    Background_Label = Label(LoginWindow, image=filename2)
    Background_Label.place(x=0, y=0, relwidth=1, relheight=1)
    #label=Label(StudentLoginWindow(),text="apple",bg="black",fg="white",height=15)
    # background_label = Label(root, image=filename2)
    # background_label.place(x=0, y=0, relwidth=1, relheight=1)
    temp_str='Welcome  '+str(login)+'  !!!'
    studentlabel=Label(LoginWindow, text=temp_str, font=("Lucida Calligraphy", 16, "bold"), pady=3, height=1, width=18)

    studentlabel.place(x=150, y=50)

    informationStudent = Button(LoginWindow, text='Student information', command=StudentInformationWindow, bd=12,
                                relief=RAISED, fg="black", bg="#20B2AA",
                                font=("Times New Roman", 36, "bold"), pady=3, height=1, width=18)
    informationStudent['font'] = BtnFont
    informationStudent.place(x=900, y=80)

    submit = Button(LoginWindow, text='Submit Leave', command=apply, bd=12, relief=RAISED, fg="black", bg="#20B2AA",
                    font=("Times New Roman", 36, "bold"), pady=3, height=1, width=18)
    submit['font'] = BtnFont
    submit.place(x=900, y=180)

    LeaveBalance = Button(LoginWindow, text='Leave Balance', command=balance, bd=12, relief=RAISED, fg="black",
                          bg="#20B2AA", font=("Times New Roman", 36, "bold"), pady=3, height=1, width=18)
    LeaveBalance['font'] = BtnFont
    LeaveBalance.place(x=900, y=280)

    LeaveApplicationStatus = Button(LoginWindow, text='Last leave status', command=StudentLeaveStatus, bd=12,
                                    relief=RAISED, fg="black", bg="#20B2AA",
                                    font=("Times New Roman", 36, "bold"), pady=3, height=1, width=18)
    LeaveApplicationStatus['font'] = BtnFont
    LeaveApplicationStatus.place(x=900, y=380)

    AllLeaveStatus = Button(LoginWindow, text='All leave status', command=StudentAllStatus, bd=12, relief=RAISED,
                            fg="black", bg="#20B2AA",
                            font=("Times New Roman", 36, "bold"), pady=3, height=1, width=18)
    AllLeaveStatus['font'] = BtnFont
    AllLeaveStatus.place(x=900, y=480)

    LogoutBtn = Button(LoginWindow, text='Logout', bd=12, relief=RAISED, fg="black", bg="#20B2AA",
                       font=("Times New Roman", 36, "bold"), pady=3, command=Studentlogout, height=1, width=18)
    LogoutBtn['font'] = BtnFont
    LogoutBtn.place(x=900, y=580)


def StudentLogin():
    message = "Enter Student ID and Password: "
    title = "Student Login"
    fieldnames = ["Student ID", "Password"]
    field = []
    field = multpasswordbox(message, title, fieldnames)

    for row in conn.execute('SELECT * FROM Student'):
        if field[0] == row[0] and field[1] == row[3]:
            global login
            login = field[0]
            f = 1
            print("Success")
            tkinter.messagebox.showinfo("Student Login", "Login Successful.")
            StudentLoginWindow()
            break
    if field[0] != row[0] and field[1] != row[3]:
        tk.showerror("Error info", "Incorrect Student id or password.")


#####################################################################################################

#####################################################################################################
# MAIN SCREEN STUFF

def render_initial_screen():
    FacultyLgnBtn = Button(root, text='Faculty login', bd=12, relief=RAISED, fg="black", bg="#20B2AA",
                           font=("Times New Roman", 30), pady=3, command=FacultyLogin, height=1, width=18)
    FacultyLgnBtn['font'] = BtnFont
    FacultyLgnBtn.place(x=900, y=250)

    LoginBtn = Button(root, text='Student login', bd=12, relief=RAISED, fg="black", bg="#20B2AA",
                      font=("Times New Roman", 36, "bold"), pady=3, command=StudentLogin, height=1, width=18)
    LoginBtn['font'] = BtnFont
    LoginBtn.place(x=900, y=350)

    StudentRegistration = Button(root, text='Student registration', command=registration, bd=12, relief=RAISED,
                                 fg="black", bg="#20B2AA", font=("Times New Roman", 36, "bold"), pady=3, height=1, width=18)
    StudentRegistration['font'] = BtnFont
    StudentRegistration.place(x=900, y=450)

    ExitBtn = Button(root, text='Exit', command=root.destroy, bd=12, relief=RAISED, fg="black", bg="#20B2AA",
                     font=("Times New Roman", 36, "bold"), pady=3, height=1, width=18)
    ExitBtn['font'] = BtnFont
    ExitBtn.place(x=900, y=550)


root = Tk()

root.wm_attributes('-fullscreen', '1')
root.title("Leave Management System")
filename = PhotoImage(file="images/lma.gif")
background_label = Label(root, image=filename)
background_label.place(x=0, y=30, relwidth=1, relheight=1)
BtnFont = Font(family='Times New Roman(Body)', size=20)
MainLabel = Label(root, text="Leave Management System", bd=5, fg="White", bg="Black",
                  font=("Times New Roman", 55, "bold"), pady=5)
MainLabel.pack(fill=X)
im = PhotoImage(file='images/img3.gif')
filename1 = PhotoImage(file="images/lma_fac.gif")
filename2 = PhotoImage(file="images/lma_stu.gif")
render_initial_screen()
root.mainloop()

#####################################################################################################

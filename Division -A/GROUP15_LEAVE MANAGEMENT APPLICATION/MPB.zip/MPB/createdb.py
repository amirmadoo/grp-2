import sqlite3

conn = sqlite3.connect('leaveDb.db')
cur = conn.cursor()

conn.execute("CREATE TABLE balance (Student_id text,sickleave int,casualleave int,emergencyleave int)")
conn.execute("CREATE TABLE status (leave_id int,Student_id text,leave text,Date1 text,Date2 text,days int,status text)")
conn.execute('''CREATE TABLE Student (Student_id text,Name text,ContactNumber text,Password text)''')

import tkinter, sqlite3, random
import tkinter.messagebox as tk
from tkinter.font import Font
from tkinter import *
from turtle import *
#from easygui import *
from student_registration import hello



import tkinter, sqlite3, random
import tkinter.messagebox as tk
from tkinter.font import Font
from tkinter import *
from turtle import *
from easygui import *
from student_registration import registration
from student import StudentLogin




total_rows = len(r)
    total_columns = len(r[0])
    for i in range(total_rows):
            for j in range(total_columns):
                 
                e = Entry(StudentInformation, width=20, fg='blue',
                               font=('Arial',16,'bold'))
                 
                e.grid(row=i, column=j)
                e.insert(END, r[i][j])